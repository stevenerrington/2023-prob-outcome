function [PDS ,c ,s]= ProbAmtIso_next(PDS ,c ,s)
%% next_trial function
% this is executed once at the beginning of each trial
% as the first step of the 'Run' action from the GUI
% (the other steps are 'run_trial' and 'finish_trial'
% This is where values are set as needed for setupthe next trial
%% increment trial count
c.j             = c.j + 1;

if c.repeatflag==0
    %% Next trial parameters
    [c, s]                  = nextparams(c, s);
else
    
end
end


function [c, s]         = nextparams(c, s)



c.fracsize=4;
c.infocuesize=1.75;

ITI_dur=3;
c.fixreq=2;
TS_dur=0.5;
CS_dur=3;%+.1;
trace_dur=0; %this is set to 0 as baseline
rewardtimeafterCSoff=[1.5 1.5 1.5];
rewardtimeafterCSoff=rewardtimeafterCSoff(randperm(length(rewardtimeafterCSoff))); rewardtimeafterCSoff=rewardtimeafterCSoff(1)
c.rewardtimeafterCSoff=rewardtimeafterCSoff;
c.CS_dur=CS_dur;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


block1 = [9800 9801 9802 9803 9804 9805 9806 9807 9808 9809]-1000; block1=[block1 block1 block1 block1];
block2 = [9800 9801 9802 9803 9804 9805 9806 9807 9808 9809]; block2=[block2 block2 block2 block2];


%block1 = [9805 9805 9805 9805 9805 9805 9805 9805 9805]-1000-5; block1=[block1 block1 block1 block1];

if c.startBlock==1
    blockorder1=[1 2 1 2 ]; %once it gets to the end of array reset and start at begining
else
    blockorder1=[2 1 2 1 ]; %once it gets to the end of array reset and start at begining
end


possibleangles=[0 180];
%you can add more spatial randomness
possibleangles_escapecue=[90 270];



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%when the task first starts these get set.
if c.j==1
    c.trialnumber_=0;
    c.blocknumid=1;
    c.BLOCKFINISHED=0;
end

%if this was set to 1 that means the block's last trial just happened
if c.BLOCKFINISHED==1
    c.trialnumber_=0;
    c.blocknumid=c.blocknumid+1;
    c.BLOCKFINISHED=0;
    if c.blocknumid>length(blockorder1)
        c.blocknumid=1;
    end
end

blocklength=length(block1);

disp('type of block')
typeofblock=blockorder1(c.blocknumid)
c.typeofblock=typeofblock;


if c.trialnumber_==0
    currentblocktrials=eval(['block' mat2str(typeofblock)]);
    currentblocktrials=currentblocktrials(randperm(length(currentblocktrials),length(currentblocktrials)));
    currentblocktrials=currentblocktrials(randperm(blocklength));  % error here on block start if probblocoonly active 15-04-08NML
    save tempnames.mat currentblocktrials;
else
    load 'tempnames.mat';
end

if length(currentblocktrials)-1==c.trialnumber_
    c.BLOCKFINISHED=1; %next trial the block will switch
end


if c.repeatflag==0
    c.previousTrialRepeated =0;
    disp('Trial number')
    c.trialnumber_=c.trialnumber_+1;
    c.trialnumber_
    fractalid1=currentblocktrials(c.trialnumber_);
    ccc = [1];
    %if fractalid1>6305
    c.fixOverlap= CS_dur-rewardtimeafterCSoff;
    %else
    %    c.fixOverlap= 0;
    %end
    if c.trialnumber_~=0
        s.successfulTrials = (s.successfulTrials +1);
    end
    
else
    
    c.repeatflag=0
    c.previousTrialRepeated =1;
    disp('Trial number')
    c.trialnumber_
    if c.trialnumber_==0
        c.trialnumber_=c.trialnumber_+1;
    end
    fractalid1=currentblocktrials(c.trialnumber_);
    %if fractalid1>6305
    c.fixOverlap= CS_dur-rewardtimeafterCSoff;
    %else
    %    c.fixOverlap=0;
    %end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dbigreward=0.3805*1.5;
dpunishment=0.2;
rewardchn=0;
punishmentchn=2;
%smallreward=0.116*1.5; %0.125mL/ squirt




if fractalid1<9000
    UItemp = randi([0 1]);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %
    if fractalid1==8800
        c.rewardDur         = dbigreward
        c.outcomechannel = rewardchn;
        if UItemp
            c.feedid=8010;
        else
            c.feedid=8000;
        end
    end
    %
    if fractalid1==8801
        if UItemp
            c.feedid=8010;
        else
            c.feedid=8000;
        end
        if randi(4)>1
            c.rewardDur         = dbigreward;
            c.outcomechannel = rewardchn;
        else
            c.rewardDur         = 0;
            c.outcomechannel = rewardchn;
        end
    end
    %
    if fractalid1==8802
        if UItemp
            c.feedid=8010;
        else
            c.feedid=8000;
        end
        if randi(4)>2
            c.rewardDur         = dbigreward;
            c.outcomechannel = rewardchn;
        else
            c.rewardDur         = 0;
            c.outcomechannel = rewardchn;
        end
    end
    
    if fractalid1==8809
        if UItemp
            c.feedid=8010;
        else
            c.feedid=8000;
        end
        if randi(4)>2
            c.rewardDur         = dbigreward;
            c.outcomechannel = rewardchn;
        else
            c.rewardDur         = dpunishment;
            c.outcomechannel = punishmentchn;
        end
    end
    
    %
    if fractalid1==8803
        if UItemp
            c.feedid=8010;
        else
            c.feedid=8000;
        end
        if randi(4)>3
            c.rewardDur         = dbigreward;
            c.outcomechannel = rewardchn;
        else
            c.rewardDur         = 0;
            c.outcomechannel = rewardchn;
        end
    end
    %
    if fractalid1==8804
        if UItemp
            c.feedid=8010;
        else
            c.feedid=8000;
        end
        c.rewardDur         = 0;
        c.outcomechannel = rewardchn;
    end
    
    if fractalid1==8805
        if UItemp
            c.feedid=8010;
        else
            c.feedid=8000;
        end
        
        c.rewardDur         = dpunishment;
        c.outcomechannel = punishmentchn;
        
    end
    %
    if fractalid1==8806
        if UItemp
            c.feedid=8010;
        else
            c.feedid=8000;
        end
        if randi(4)>1
            c.rewardDur         = dpunishment;
            c.outcomechannel = punishmentchn;
        else
            c.rewardDur         = 0;
            c.outcomechannel = punishmentchn;
        end
    end
    %
    if fractalid1==8807
        if UItemp
            c.feedid=8010;
        else
            c.feedid=8000;
        end
        if randi(4)>2
            c.rewardDur         = dpunishment;
            c.outcomechannel = punishmentchn;
        else
            c.rewardDur         = 0;
            c.outcomechannel = punishmentchn;
        end
    end
    if fractalid1==8808
        if UItemp
            c.feedid=8010;
        else
            c.feedid=8000;
        end
        if randi(4)>3
            c.rewardDur         = dpunishment;
            c.outcomechannel = punishmentchn;
        else
            c.rewardDur         = 0;
            c.outcomechannel = punishmentchn;
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
elseif fractalid1>9000
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %
    if fractalid1==9800
        c.rewardDur         = dbigreward
        c.outcomechannel = rewardchn;
        c.feedid=8001;
    end
    %
    if fractalid1==9801
        if randi(4)>1
            c.rewardDur         = dbigreward;
            c.outcomechannel = rewardchn;
            c.feedid=8001;
        else
            c.rewardDur         = 0;
            c.outcomechannel = rewardchn;
            c.feedid=8002;
        end
    end
    %
    if fractalid1==9802
        if randi(4)>2
            c.feedid=8001;
            c.rewardDur         = dbigreward;
            c.outcomechannel = rewardchn;
        else
            c.rewardDur         = 0;
            c.outcomechannel = rewardchn;
            c.feedid=8002;
        end
    end
    
    if fractalid1==9809
        if randi(4)>2
            c.feedid=8001;
            c.rewardDur         = dbigreward;
            c.outcomechannel = rewardchn;
        else
            c.feedid=8003;
            c.rewardDur         = dpunishment;
            c.outcomechannel = punishmentchn;
        end
    end
    
    
    %
    if fractalid1==9803
        if randi(4)>3
            c.feedid=8001;
            c.rewardDur         = dbigreward;
            c.outcomechannel = rewardchn;
        else
            c.rewardDur         = 0;
            c.outcomechannel = rewardchn;
            c.feedid=8002;
        end
    end
    %
    if fractalid1==9804
        c.rewardDur         = 0;
        c.outcomechannel = rewardchn;
        if randi(2)==1
            c.feedid=8002;
        else
            c.feedid=8004;
        end
    end
    
    if fractalid1==9805
        c.feedid=8003;
        c.rewardDur         = dpunishment;
        c.outcomechannel = punishmentchn;
        
    end
    %
    if fractalid1==9806
        if randi(4)>1
            c.feedid=8003;
            c.rewardDur         = dpunishment;
            c.outcomechannel = punishmentchn;
        else
            c.feedid=8004;
            c.rewardDur         = 0;
            c.outcomechannel = punishmentchn;
        end
    end
    %
    if fractalid1==9807
        if randi(4)>2
            c.feedid=8003;
            c.rewardDur         = dpunishment;
            c.outcomechannel = punishmentchn;
        else
            c.feedid=8004;
            c.rewardDur         = 0;
            c.outcomechannel = punishmentchn;
        end
    end
    if fractalid1==9808
        if randi(4)>3
            c.feedid=8003;
            c.rewardDur         = dpunishment;
            c.outcomechannel = punishmentchn;
        else
            c.feedid=8004;
            c.rewardDur         = 0;
            c.outcomechannel = punishmentchn;
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
end

%if the trial type is 1, it means its a choice. run choicetrials and get
%the two fractals for choice
if fractalid1==1
    if c.typeofblock<3
        [fractalid1 , s] =choicetrials(c,s);
    elseif c.typeofblock>2
        [fractalid1 , s] =choicetrials2(c,s);
    end
end
c.fractalid=fractalid1;


s.TrialType     = fractalid1(1);
try
    s.TrialType1=[];
    s.TrialType1    = fractalid1(2);
end

s.blocknumber =c.blocknumid;



c.forcedorchoice=1;
[CLUTS, images] = CLUTmaker([fractalid1 c.feedid], c);
if size(CLUTS,1) < 246
    CLUTS(length(CLUTS)+1:246,:)=0;
end
c.im1=images(1).im1i;
c.im2=[];
c.im3=images(1).im2i;

c.humanColors(10,:)=c.mutedGreen;
c.monkeyColors(10,:)=c.mutedGreen;


c.humanColors(10,:)=c.colortwo;
c.monkeyColors(10,:)=c.colortwo;

% if c.fixreq==1
%     c.humanColors(10,:)=c.colorone;
%     c.monkeyColors(10,:)=c.colorone;
% end

%this gets rid of any black or near back in the images and sets it to
% %background color wihch is c.bgRGB (defined in _init)
for xx=1:size(CLUTS,1)
    if mean(CLUTS(xx,:))<0.3 %this is a threshold we found to work. test each fractal to make sure its correct
        CLUTS(xx,:)=   c.bgRGB; % this is grey...;
    end
end


c.humanCLUT                                     = c.humanColors;
c.monkeyCLUT                                    = c.monkeyColors;
c.humanCLUT(length(c.humanColors)+1:256,:)      = hsv2rgb(hsv(256-length(c.humanColors)));
c.monkeyCLUT(length(c.monkeyColors)+1:256,:)    = hsv2rgb(hsv(256-length(c.monkeyColors)));



c.humanCLUT(length(c.humanColors)+1:256,:)      = (CLUTS);
c.monkeyCLUT(length(c.monkeyColors)+1:256,:)    = (CLUTS);
c.combinedClut = [c.monkeyCLUT;c.humanCLUT];
Datapixx('SetVideoMode', 5);
Datapixx('SetVideoClut', c.combinedClut);
Datapixx('RegWrRd');





% choose a target location at random%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[z,randloc]=min(rand(1,length(possibleangles))); %generate a number 1 through 3 randomly
location=possibleangles(randloc); clear z randloc
c.targAngle             = location; %rand*360;
if location>-1
    c.targAmp               = round(c.minTargAmp - 0.5 + rand*(c.maxTargAmp - c.minTargAmp));
    s.targXY                = c.targAmp*[cosd(c.targAngle), sind(c.targAngle)];
else %-1 means center where the fixation spot is
    c.targAmp               = 0;
    s.targXY                = [0 0];
end


%if trace is present
trace_dur=0; %this is set to 0 as baseline
trace_present=0;
trace_random=0;
if trace_present ==1 && trace_random ==0
    CS_dur=1.5;
    trace_dur=1; %this is set to 0 as baseline
elseif trace_present ==1 && trace_random ==1
    CS_dur=[1 1.5 2];
    [z,randnum]=min(rand(1,3)); %1 through 3 rand
    CS_dur=CS_dur(randnum);
    trace_dur=2.5-CS_dur;
end

%
% %escapecue frequency // this cue appear in 1 of 2 locations (top or bottom 10deg)
% if typeofblock>2
%     escapecuefreq=[0 0 0 0]; %1/4 trials
% else typeofblock<3
%     escapecuefreq=[0 0 0 0]; %1/4 trials
% end
% [z,randnum]=min(rand(1,4));
% escapecuefreq=escapecuefreq(randnum);
% escapecuetime=[1]; %1/4 trials
% [z,randnum]=min(rand(1,1));
% escapecuetime=escapecuetime(randnum);
% %
% possibleangles_escapecue=[90 270];
% [z,randnum]=min(rand(1,2));
% possibleangles_escapecue=possibleangles_escapecue(randnum);
% c.angles_escapecue=possibleangles_escapecue;
% c.escapeAmp               = round(c.minTargAmp - 0.5 + rand*(c.maxTargAmp - c.minTargAmp));;
% s.escapeXY                = c.escapeAmp*[cosd(possibleangles_escapecue), sind(possibleangles_escapecue)];
% c.escapecuefreq=escapecuefreq;
% c.escapecuetime=escapecuetime;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


c.ITI_dur=ITI_dur;
c.TS_dur=TS_dur;
c.CS_dur=CS_dur;
c.trace_dur=trace_dur;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%things occur during ITI -- organize them separately in to a trial
%sub-structure
%%%
%ITI EVENTS ARE DEFINED IN THE ARRAY: setupITI below
%-unexpected reward -1
%-unexpected sound -2
%-unexpected screen flash -3
%-unexpected monkey face -4
%-unexpected free looking array (the actual stims in the array are indicated
%elsewhere) -5
%-NOTHING occurs during ITI - 0
%%%
%NOTE FOR FREE LOOKING ARRAY WITH STIMS (READ CAREFULLY BEFORE CHANGING)
%the sets are trained separately in a different procedure.
%each set starts with 0 and goes through 8. so there are 9 total fractals
%the first 3 are rewarding, the next 3 are neutral, and the next 3 are
%punishing.
%%%
%%%
%%%
%%%

setupITI=  [0 0 0 0 0]; % [1 1 1 1 1]; %    [0 0 0 0 0 1] %
%   if 0 don't do any ITI.if we start doing this carefully check the timing of everything!!!!
randnum=randperm(5); randnum=randnum(1);
c.setupITI=setupITI(randnum); clear randnum setupITI
if c.probblockonly==1
    c.setupITI=0;
end

freeoutcometype=[0 0];
randnum=randperm(length(freeoutcometype)); randnum=randnum(1);
c.freeoutcometype=freeoutcometype(randnum); clear randnum setupITI





possibleangles_freelook=randperm(2); possibleangles_freelook=possibleangles_freelook(1);
if possibleangles_freelook==1
    possibleangles_freelook=[0 90 180 270];
elseif possibleangles_freelook==2
    possibleangles_freelook=[45 135 225 315];
end
c.possibleanglesfreelook=possibleangles_freelook;
c.freelookamp=10;



% ITItime=[2.5 2 1.5];
% randnum=randperm(3); randnum=randnum(1);
% c.ITItime=ITItime(randnum); clear randnum ITItime
% c.ITIstimdur=2.5;



ITIRANGE=[1800:2800];
ITIRANGE=ITIRANGE(randperm(length(ITIRANGE)));
c.ITItime=ITIRANGE(1)/1000;
clear randnum ITItime







%
% blocktrial=1;
% %FOR NOW JUST GRAB THE FIRST FRACTAL
% fractalid1=block1(blocktrial);
% fractalfile1=['i' int2str(fractalid1) '.tif'];
%
% %load image stimuli
% cd fractals
% im=imread(fractalfile1);
% cd ..
%
% [images, CLUTS] = rgb2ind(im, 246);
% c.im1=images+10; %pass this image to display
%
% %test multipe images
% %testimag=[6312 6306 6301 6300];
% %[CLUToutput, IMAGES]=CLUTmaker(testimag);
%
% c.humanCLUT(length(c.humanColors)+1:256,:)      = (CLUTS);
% c.monkeyCLUT(length(c.monkeyColors)+1:256,:)    = (CLUTS);
% c.combinedClut = [c.monkeyCLUT;c.humanCLUT];
%
%
% Datapixx('SetVideoClut', c.combinedClut);
% Datapixx('RegWrRd');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



end
%
function [CLUT_, images_]        =   CLUTmaker(trialimagesid, c)

im1=[];
im2=[];
im3=[];
im4=[];

oneimage=0;
if size(trialimagesid,2)==1
    oneimage=1;
end

for getim=1:size(trialimagesid,2)
    % if c.fixreq == 1
    %     readinimage=['i' int2str(trialimagesid(getim)) '.tif'];
    % elseif c.fixreq == 2
    readinimage=['j' int2str(trialimagesid(getim)) '.tif'];
    % end
    
    cd fractals
    readinimage=imread(readinimage);
    cd ..
    if size(trialimagesid,2)>1 %get all the images to make CLUTs
        
        if getim==1
            im1=readinimage;
        elseif getim==2
            im2=readinimage;
        elseif getim==3
            im3=readinimage;
        elseif getim==4
            im4=readinimage;
        end
        
    elseif size(trialimagesid,2)==1
        im1=readinimage;
        im2=readinimage;
    end
    clear readinimage getim
end


% what are their sizes?
% least ONE dimension is common between the images.
% first, make a big image by appending one image to the other.
%bigIm = [im1(1:min([n1 n3]),:,:), im2];

n1=[]; n3=[]; n5=[]; n7=[];
try
    [n1, n2, ~] = size(im1);
    [n3, n4, ~] = size(im2);
    [n5, n6, ~] = size(im3);
    [n7, n8, ~] = size(im4);
end
dimentest=nonzeros([n1, n3, n5, n7]);
mindimen=find(dimentest==min(dimentest)); mindimen=mindimen(1);
mindimen=dimentest(mindimen);
try
    im1=im1(1:mindimen,:,:);
    im2=im2(1:mindimen,:,:);
    im3=im3(1:mindimen,:,:);
    im4=im4(1:mindimen,:,:);
end
dimentest=nonzeros([n2, n4, n6, n8]);
mindimen=find(dimentest==min(dimentest)); mindimen=mindimen(1);
mindimen=dimentest(mindimen);
try
    im1=im1(:,1:mindimen,:);
    im2=im2(:,1:mindimen,:);
    im3=im3(:,1:mindimen,:);
    im4=im4(:,1:mindimen,:);
end

if isempty(im3)==1 && isempty(im4)==1
    bigIm=[im1,im2];
    % make an indexed version of the appended big image, and a CLUT
    [imIndexed, CLUT_] = rgb2ind(bigIm, 246, 'nodither');
    
    
elseif isempty(im3)==0 && isempty(im4)==0
    bigIm=[im1,im2,im3, im4];
    [imIndexed, CLUT_] = rgb2ind(bigIm, 246, 'nodither');
end

% separate the big indexed image
im1i=[]; im2i=[]; im3i=[]; im4i=[];
try
    im1i    = imIndexed(:, 1:size(imIndexed,2)/size(trialimagesid,2));
    im2i    = imIndexed(:, (size(imIndexed,2)/size(trialimagesid,2)+1):(2*size(imIndexed,2)/size(trialimagesid,2)));
    im3i    = imIndexed(:, (2*(size(imIndexed,2)/size(trialimagesid,2)))+1:(3*size(imIndexed,2)/size(trialimagesid,2)));
    im4i    = imIndexed(:, (3*(size(imIndexed,2)/size(trialimagesid,2)))+1:(4*size(imIndexed,2)/size(trialimagesid,2)));
end

if oneimage==1
    im2i=[];
    im3i=[];
    im4i=[];
end

if size(CLUT_,1) < 246
    CLUT_(length(CLUT_)+1:246,:)=0;
end
try
    images_(1).im1i=convertIndexedImageToL48DImage(im1i+10);
    images_(1).im2i=convertIndexedImageToL48DImage(im2i+10);
    images_(1).im3i=convertIndexedImageToL48DImage(im3i+10);
    images_(1).im4i=convertIndexedImageToL48DImage(im4i+10);
end


clear im1i im2i im3i im4i

end









