function codes = stimcodes

% This file contains the 'timestamp' and stimulus 'tag' codes that are
% Strobed by PLDAPS to the Omniplex system.
% WARNING: This is the key to the data. DO NOT change the contents of this
% file.

%% 
%codes.start = 1000;
%codes.stop = 1010;
codes.trialBegin = 1001;
codes.trialEnd = 1009;
codes.connectPLX = 11001;
codes.trialcount = 11002;
codes.trialnumber = 11003;
codes.blocknumber = 11004;
codes.state       = 11005;


codes.choicerefuse       = 3005;


codes.nonstart = 2006;
codes.fixbreak = 2007;
codes.fixacqd = 2008;

codes.fixdoton = 3001;
codes.fixdotoff = 3003;

codes.abortatfixation=3004;
%
codes.targeton = 4001;
codes.targetoff = 4003;
codes.targetonnofix = 4004;
codes.screenclear = 4005;

codes.startsendingtrialinfo=5000;
codes.endsendingtrialinfo=5001;

codes.window1chosen=9000;
codes.window2chosen=9001;
codes.choicetimeout=9002;



codes.monkeyescaped=9005;
codes.freereward=9006;
codes.freeairpuff=9006;
codes.monkeyface=9007;
codes.freelookarray=9008;

codes.monkeyenteredtargwin=9103; %NML testCode


%
codes.reward = 8000;
codes.noreward = 8001;
codes.airpuff = 8002;
codes.noairpuff = 8003;
%
codes.microstimon = 7001;
codes.saconset = 7005;

% 9000s already used for choice trials and aversive/social stimuli
% codes.lowtone = 9001;
% codes.noisetone = 9002;
% codes.hightone = 9003;
% % 9000s already used for choice trials and aversive/social stimuli
codes.lowtone = 9011;
codes.noisetone = 9012;
codes.hightone = 9013;
codes.freeflashsound= 9014;
codes.freesound=9015;
codes.freeflashsound=9016;
codes.freeflash=9010;

codes.freeflashsoundleftleft=9017;
codes.freeflashsoundleftrigh=9018;
codes.freeflashsoundrightright=9019;
codes.freeflashsoundrightleft=9020;
codes.freesmallreward=9021;
























